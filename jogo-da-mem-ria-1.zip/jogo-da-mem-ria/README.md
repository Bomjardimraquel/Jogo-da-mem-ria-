# Jogo da memória

A Pen created on CodePen.

Original URL: [https://codepen.io/Raquel-Ferreira/pen/xbxZbvX](https://codepen.io/Raquel-Ferreira/pen/xbxZbvX).

